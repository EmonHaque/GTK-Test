#include <gtk/gtk.h>
#include <stdio.h>

GtkWidget *stack;

static void onToggled (GtkToggleButton *source, void* page){
    gtk_stack_set_visible_child(stack, page);
}
static void activate(GtkApplication *app, void *data) {
    GtkWidget *window = gtk_application_window_new(app);
    GtkWidget *titleBar = gtk_header_bar_new();
    GtkWidget *title = gtk_label_new("Title");
    GtkWidget *icon = gtk_image_new_from_file("icon.png");
    
    gtk_window_set_titlebar(window, titleBar);
    gtk_window_set_default_size(window, 640, 480);
    
    gtk_image_set_icon_size(icon, GTK_ICON_SIZE_LARGE);
    gtk_header_bar_pack_start(titleBar, icon);
    gtk_header_bar_set_show_title_buttons(titleBar, TRUE);
    gtk_header_bar_set_title_widget(titleBar, title);
    
    GtkWidget *page1 = gtk_grid_new();
    GtkWidget *button1 = gtk_button_new_with_label("button1");
    GtkWidget *label1 = gtk_label_new(0);
    GtkWidget *textView1 = gtk_text_view_new();
    GtkWidget *entry1 = gtk_entry_new();
    GtkWidget *scrolledwindow1 = gtk_scrolled_window_new();

    gtk_entry_set_max_length(entry1, 15);
    gtk_widget_set_tooltip_text(button1, "A button");

    gtk_widget_set_hexpand(textView1, TRUE);
    gtk_widget_set_vexpand(textView1, TRUE);

    gtk_text_view_set_wrap_mode(textView1, GTK_WRAP_WORD);
    gtk_scrolled_window_set_child(scrolledwindow1, textView1);
    gtk_entry_set_placeholder_text(entry1, "Hello");
    gtk_entry_set_icon_from_icon_name(entry1, GTK_ENTRY_ICON_PRIMARY, "phone");
    gtk_entry_set_icon_from_icon_name(entry1, GTK_ENTRY_ICON_SECONDARY, "phone");

    gtk_grid_attach(page1, button1, 0, 0, 1, 1);
    gtk_grid_attach(page1, label1, 0, 1, 1, 1);
    gtk_grid_attach(page1, scrolledwindow1, 0, 2, 1, 1);
    gtk_grid_attach(page1, entry1, 0, 3, 1, 1);

    GtkWidget *page2 = gtk_grid_new();
    GtkWidget *button2 = gtk_button_new_with_label("button2");
    GtkWidget *textView2 = gtk_text_view_new();
    GtkWidget *entry2 = gtk_entry_new();
    GtkWidget *scrolledwindow2 = gtk_scrolled_window_new();
    gtk_widget_set_hexpand(textView2, TRUE);
    gtk_widget_set_vexpand(textView2, TRUE);
    gtk_scrolled_window_set_child(scrolledwindow2, textView2);
    gtk_grid_attach(page2, button2, 0, 0, 1, 1);
    gtk_grid_attach(page2, scrolledwindow2, 0, 1, 1, 1);
    gtk_grid_attach(page2, entry2, 0, 2, 1, 1);

    GtkWidget *page3 = gtk_grid_new();
    GtkWidget *button3 = gtk_button_new_with_label("button3");
    gtk_grid_attach(page3, button3, 0, 0, 1, 1);

    GtkWidget *toggle1 = gtk_toggle_button_new();
    GtkWidget *toggle2 = gtk_toggle_button_new();
    GtkWidget *toggle3 = gtk_toggle_button_new();
    GtkWidget* togContainer = gtk_box_new(GTK_ORIENTATION_VERTICAL, 1);
    gtk_button_set_icon_name(toggle1, "user-home-symbolic");
    gtk_button_set_icon_name(toggle2, "phone");
    gtk_button_set_icon_name(toggle3, "call-start-symbolic");
    gtk_box_append(togContainer, toggle1);
    gtk_box_append(togContainer, toggle2);
    gtk_box_append(togContainer, toggle3);

    gtk_toggle_button_set_active(toggle1, TRUE);
    gtk_toggle_button_set_group(toggle1, toggle2); // what do you do in a group of 10 toggle buttons?
    gtk_toggle_button_set_group(toggle1, toggle3);
    gtk_toggle_button_set_group(toggle2, toggle3);

    g_signal_connect(toggle1, "toggled", onToggled, page1);
    g_signal_connect(toggle2, "toggled", onToggled, page2);
    g_signal_connect(toggle3, "toggled", onToggled, page3);

    stack = gtk_stack_new();
    gtk_stack_set_transition_type(stack, GTK_STACK_TRANSITION_TYPE_SLIDE_LEFT_RIGHT);
    gtk_stack_set_transition_duration(stack, 1000);
    gtk_stack_add_child(stack, page1);
    gtk_stack_add_child(stack, page2);
    gtk_stack_add_child(stack, page3);
    
    GtkWidget *stackContainer = gtk_grid_new();
    gtk_grid_attach(stackContainer, togContainer, 0, 0, 1, 1);
    gtk_grid_attach(stackContainer, stack, 1, 0, 1, 1);
    gtk_window_set_child(window, stackContainer);
    gtk_widget_show(window);
}

int main(int argc, char **argv) {
    GtkApplication *app = gtk_application_new("why.doted.id", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", activate, NULL);
    int status = g_application_run(app, argc, argv);
    g_object_unref(app);
    return status;
}