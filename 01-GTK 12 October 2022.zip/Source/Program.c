#include <gtk/gtk.h>
#include <stdio.h>

//signature coorrect?
static void onMouseEnterIcon(GtkEventControllerMotion *sender, double x, double y, void* arg){
    GtkImage *icon = arg;
    printf("Entered\n");
}
//signature coorrect?
static void onMouseLeaveIcon(GtkEventControllerMotion *sender, void* arg){
    GtkImage *icon = arg;
    printf("Entered\n");
}
static void onButton1Clicked(GtkWidget *sender, void* arg){
    GtkWidget *label = arg;
    static int clickCount = 0;
    clickCount++;
    char buff[64];
    sprintf(buff, "clicked %d", clickCount);
    gtk_label_set_text(label, buff);
}

static void activate(GtkApplication *app, void *data) {
    GtkWidget *window = gtk_application_window_new(app);
    //GtkWidget *windowGrid = gtk_grid_new();
    GtkWidget *titleBar = gtk_header_bar_new();
    GtkWidget *title = gtk_label_new("Title");
    GtkWidget *icon = gtk_image_new_from_file("icon.png");

    //gtk_window_set_child(window, windowGrid);
    //gtk_window_set_decorated(window, FALSE);
    //gtk_window_set_resizable(window, TRUE); // does not work if undecorated
    gtk_window_set_titlebar(window, titleBar);
    gtk_window_set_default_size(window, 640, 480);
    
    gtk_image_set_icon_size(icon, GTK_ICON_SIZE_LARGE);
    gtk_header_bar_pack_start(titleBar, icon);
    gtk_header_bar_set_show_title_buttons(titleBar, TRUE);
    gtk_header_bar_set_title_widget(titleBar, title);
    
    //gtk_grid_attach(windowGrid, titleBar, 0, 0, 1, 1);
    //gtk_grid_set_column_homogeneous(windowGrid, TRUE);

    GtkEventController *motion = gtk_event_controller_motion_new();
    gtk_widget_add_controller(icon, motion);
    g_signal_connect(motion, "enter", onMouseEnterIcon, icon);
    g_signal_connect(motion, "leave", onMouseLeaveIcon, icon);

    GtkWidget *page1 = gtk_grid_new();
    GtkWidget *button1 = gtk_button_new_with_label("button1");
    GtkWidget *label1 = gtk_label_new(0);
    GtkWidget *textView1 = gtk_text_view_new();
    GtkWidget *entry1 = gtk_entry_new();
    GtkWidget *scrolledwindow1 = gtk_scrolled_window_new();

    g_signal_connect(button1, "clicked", onButton1Clicked, label1);
    gtk_entry_set_max_length(entry1, 15);
    gtk_widget_set_tooltip_text(button1, "A button");

    gtk_widget_set_hexpand(textView1, TRUE);
    gtk_widget_set_vexpand(textView1, TRUE);

    gtk_text_view_set_wrap_mode(textView1, GTK_WRAP_WORD);
    gtk_scrolled_window_set_child(scrolledwindow1, textView1);
    gtk_entry_set_placeholder_text(entry1, "Hello");
    gtk_entry_set_icon_from_icon_name(entry1, GTK_ENTRY_ICON_PRIMARY, "phone"); // svg-data doesn't work?
    gtk_entry_set_icon_from_icon_name(entry1, GTK_ENTRY_ICON_SECONDARY, "phone");

    gtk_grid_attach(page1, button1, 0, 0, 1, 1);
    gtk_grid_attach(page1, label1, 0, 1, 1, 1);
    gtk_grid_attach(page1, scrolledwindow1, 0, 2, 1, 1);
    gtk_grid_attach(page1, entry1, 0, 3, 1, 1);

    GtkWidget *page2 = gtk_grid_new();
    GtkWidget *button2 = gtk_button_new_with_label("button2");
    GtkWidget *textView2 = gtk_text_view_new();
    GtkWidget *entry2 = gtk_entry_new();
    GtkWidget *scrolledwindow2 = gtk_scrolled_window_new();
    gtk_widget_set_hexpand(textView2, TRUE);
    gtk_widget_set_vexpand(textView2, TRUE);
    gtk_scrolled_window_set_child(scrolledwindow2, textView2);
    gtk_grid_attach(page2, button2, 0, 0, 1, 1);
    gtk_grid_attach(page2, scrolledwindow2, 0, 1, 1, 1);
    gtk_grid_attach(page2, entry2, 0, 2, 1, 1);

    GtkWidget *stack = gtk_stack_new();
    GtkWidget *sideBar = gtk_stack_sidebar_new();
    GtkWidget *stackContainer = gtk_grid_new();
    gtk_stack_sidebar_set_stack(sideBar, stack);
    gtk_stack_set_transition_type(stack, GTK_STACK_TRANSITION_TYPE_SLIDE_LEFT_RIGHT);
    gtk_stack_add_titled(stack, page1, "grid1", "Page 1"); // no svg-icon only GtkStackPage
    gtk_stack_add_titled(stack, page2, "grid2", "Page 2");
    gtk_stack_set_transition_duration(stack, 1000);

    gtk_grid_attach(stackContainer, sideBar, 0, 0, 1, 1);
    gtk_grid_attach(stackContainer, stack, 1, 0, 1, 1);
    //gtk_grid_attach(windowGrid, stackContainer, 0, 1, 1, 1);
    gtk_window_set_child(window, stackContainer);

    gtk_widget_show(window);
}

int main(int argc, char **argv) {
    GtkApplication *app = gtk_application_new("why.doted.id", G_APPLICATION_DEFAULT_FLAGS);
    g_signal_connect(app, "activate", activate, NULL);
    int status = g_application_run(app, argc, argv);
    g_object_unref(app);
    return status;
}